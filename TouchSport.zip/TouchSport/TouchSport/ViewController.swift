//
//  ViewController.swift
//  TouchSport
//
//  Created by Treinamento on 12/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class Esportes{
    
    var informacoes : [String] = []
    var modalidades : [String] = []
    var beneficios : [String] = []
    var regas : [String] = []
    var image = UIImage()
}

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var arrayOfSports: [Esportes] = []
    
    var futebol = Esportes()
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrayOfSports.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = SportsCollectionViewCell()
        cell.sportImage.image = self.arrayOfSports[indexPath.row].image
        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        futebol.informacoes.insert("Jogado entre dois times de 11 jogadores cada um e um árbitro que se ocupa da correta aplicação das normas. O objetivo do jogo é deslocar uma bola através do campo para colocá-la dentro da baliza adversária, ação que se denomina gol, A equipe que marca mais gols ao término da partida é a vencedora.", at:0)
        
        futebol.modalidades.insert("Futebol de salão", at:0)
        futebol.modalidades.insert("Futebol de areia", at:1)
        futebol.modalidades.insert("Futebol de pântano", at:2)
        futebol.modalidades.insert("Futebol paraolímpico", at:3)
        futebol.modalidades.insert("Futebol de Pântano", at:4)
        futebol.modalidades.insert("Futebol Paraolímpico", at:5)
        futebol.modalidades.insert("Showbol", at:5)
        
        futebol.beneficios.insert("Diminuição da gordura corporal", at:0)
        futebol.beneficios.insert("Manutenção do peso", at:1)
        futebol.beneficios.insert("Aumento da força e da massa muscular", at:2)
        futebol.beneficios.insert("Aumento da densidade óssea", at:3)
        futebol.beneficios.insert("Melhora da resistência cardiovascular    ", at:4)
        futebol.beneficios.insert("Elimina o estresse e a ansiedade", at:5)
        futebol.beneficios.insert("Diminui a frequência cardíaca em repouso", at:6)
        futebol.beneficios.insert("Estimula a circulação sanguínea", at:7)
        
        futebol.regas.insert("Correr atrás da bola", at: 0)
        
        
        
        arrayOfSports.append(futebol)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

